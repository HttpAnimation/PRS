gcc server.c -o PRS-Server
gcc client.c -o PRS-Client